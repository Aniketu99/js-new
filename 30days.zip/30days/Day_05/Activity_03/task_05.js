//sum arrow function 

let sum = (num1, num2)=>{
    return num1 + num2;
 }

 console.log(sum(3,2));