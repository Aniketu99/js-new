// max num

function maxNum(num1, num2){
    if(num1 > num2){
        return "num1 is grater"
    }else{
        return "num2 is grater"
    }
}

console.log(maxNum(5,6));