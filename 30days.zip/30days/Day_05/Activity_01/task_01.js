// even odd

function isEven(num){

    if(num % 2 == 0){
        console.log("event");
    }else{
        console.log("odd");
    }
}

isEven(5);