// square

function square(num){
    return  num * num;
  }
  
console.log(square(9));