////default function parameter

let person = function(name, age=18){
    console.log(name);
     console.log(age);
 }
 
 person("aniket", 25)
 person("ram")     
 