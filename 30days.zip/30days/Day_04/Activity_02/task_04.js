//print no 10 to 1 with while loop

let i = 10;

while(i > 0){
    console.log(i);
    i--;
}