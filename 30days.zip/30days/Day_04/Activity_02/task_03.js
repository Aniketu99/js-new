//sum of 1 to 10 no with while loop

let sum = 0;
let i = 1;

while(i <= 10){
    sum += i;
    i++;
}

console.log(sum);