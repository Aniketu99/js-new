// print no 1 to 5 using do while loop

let i = 1;

do{
    console.log(i);
    i++;
}while(i <= 5)