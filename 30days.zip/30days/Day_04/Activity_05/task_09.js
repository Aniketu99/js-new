
//print no from 1 to 10 break loop on 7 

for(let i = 1; i <= 10; i++){
    if(i == 7){
       break;
    }
    console.log(i)
}