
// square pattern

// for(let i =0; i<5; i++){
//     for(let j=0; j<5; j++){
//         console.log("*");
//     }
// }

for (let i = 0; i < 5; i++) {
    let row = "";
    for (let j = 0; j < 5; j++) {
        row += "* ";
    }
    console.log(row); 
}