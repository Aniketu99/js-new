//print no from 1 to 10 using for loop

for(let i = 1; i <= 10; i++){
    console.log(i)
}

//print no from 1 to 10 using while loop

let i = 1;

while(i <= 10){
    console.log(i);
    i++;
}