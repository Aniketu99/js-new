//factorial of no using do while loop

let fact = 1;
let i = 1;
let num = 5;

do{
    fact = fact * i;
    i++;
}while(i <= 5);

console.log(fact);