// multiplication table of 5

let num = 5;

for(let i = 1; i <= 10; i++){
    console.log(`${num} * ${i} = ${num * i}`);
}