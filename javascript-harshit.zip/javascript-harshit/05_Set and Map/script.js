// iterables
// which can be itrable with for of loop
// string , array are iterables

//with string
const firstName = "Harshit";
for(let char of firstName){
    console.log(char);
}

//with array
const item = ['item1','item2','item3'];
for(let item of item){
    console.log(item);
}

//object can not be itrable
var obj = {
    fname:"Aniket",
    lastName:"ugare"
}

for(let val of obj){
    console.log(val);  //obj is not itrable
}
//string is array like object which has length 

var fname = "aniket";
console.log(fname.length);
console.log(fname[0]); //thats why string is array like object


//sets in js 
//set is iterable
//set use to store data
//set value cant be access with index there is no index
//set has its owns methods like has and add
//set contain unique value (duplicate are not allowed in set)
//not in order

var setArr = [10,20,30,40,50,10,30,20];
var numbers = new Set(setArr); //its only take itrable value
var len = 0;
for(number of numbers){
    len++;
    console.log(number);  //we cant print length of set using length method but we can calculate length
}
console.log("length of number set is : ",len);

//we can add elements in set

var numbers = new Set([1,2,3]);
var arr2 = [6,7,8,9,10]
numbers.add(4);
numbers.add(5);
numbers.add(arr2);
numbers.add(arr2); // this array is not add again because address of this array is already there
numbers.add(['item1,item2']); 
numbers.add(['item1,item2']); //this is add beacuse address of array is different

console.log(numbers);

if(numbers.has(2)){
    console.log("present")
}

/*
  output 

  Set(8) {
  1,
  2,
  3,
  4,
  5,
  [ 6, 7, 8, 9, 10 ],
  [ 'item1,item2' ],
  [ 'item1,item2' ]
}
present

*/

//usecase ->
//set is use for store unique value 


//map in js 
//we can use map to store key value pair in obj type of key is string or symbol but in
//map map u can set any type of key
//map is iterable
//it is in order

const person = new Map();
person.set("fname","Aniket");
person.set(1,"id");
person.set([1,2],"array");
person.set({},"object");
console.log(person.get("fname"))

for(key of person.keys()){
    console.log(typeof key)
}

for (const [key , value] of person) {
    console.log(key,value)
}

var person2 = new Map([['fname','aniket'],['id',1]]);
console.log(person2);


var obj = {
    fname :"aniket",
    id:12
}

let person3 = new Map();
person3.set(obj,{saname : "ugare"});

console.log(person3.get(obj).saname);


// clone using object.assign 

const obj = {
    key1:"value1",
    key2:"value2"
}

const obj2 = obj;

console.log(obj);
console.log(obj2);

obj.key3 ="value3";

//I have changed assign key to obj 1 but it will be assign it to both object because there is 
//object value store in heap and obj and obj2 are refrence varibale which point to same value.

console.log(obj); 
console.log(obj2);

const obj3 = Object.assign({},obj);

obj.key4 ="value4";

console.log(obj);
console.log(obj3);


// optional chaining
// if there is no property in object then its showing undefined. if we are not doing optional chaning 
// then its shows us error.


var person6 = {
   fname : 'Aniket',
   address : {code:1234},
}

console.log(person6.fname); // output is Aniket
console.log(person6.address.code); // output is 1234 

//if obj like this some time we can add properties at runtime at that time we dont want any error

var person6 = {
    fname : 'ANiket',
}

console.log(person6.fname); // output is Aniket
console.log(person6.address); //output is undefined
console.log(person6.address.code); // output is error resolve this use optional chaining

console.log(person6?.fname); // output is Aniket
console.log(person6?.address); //output is undefined
console.log(person6?.address?.code); // output is undefined

