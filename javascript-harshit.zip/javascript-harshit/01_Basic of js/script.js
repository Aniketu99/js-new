// history of js 
//javascript is build by Brendan Eich in 1995.
//javascript is know as livescript at that time but at that time java is famus language that why for 
//popularity purpose livescript become javascript.

//Ecma 
//Ecma is autority which is standardized language rules it is standardized javascript to run in different browser
//before standardized different browser different rules for langauges
//In 2009 es5 version - lot of new featcures.
//In 2015 es6 version - biggest update  in js .
//after 2015 there version relese every year like es2015 es2016.

console.log("Hello World")  // -> print in console

// variables -> variable is a container which can store data.

var firstName = "Aniket";
console.log(firstName);

firstName = "ram";
console.log(firstName);

//rules for naming varibale 
//1. not start with num
//2. user A,a,num,_ for variable name;
//3.cant user space
//4 small and big case are different.

//let keyword
// declare variable with let keyword.
//difference

// var name = "Aniket";  we can declare variable with same name multiple time with var
// var name = "ram";
// let name = "ANiket";  
// let name = "ram"     here we cant redeclare variable with same name error idetify is declared before

// Anothere difference is block scope and function scope.

// declare constants
//constant we cant change or reassign 
const pi = 3.14;
console.log(pi);
// pi = 2.14   we cant do this 

// String indexing 
// JavaScript Strings are immutable
let firstname = "Aniket"
// A n i k e t
// 0 1 2 3 4 5 
console.log(firstname[3]) // k print in console.

//string methods
//string methods return new string because Strings are immutable in js

//length of string
console.log(firstname.length); //print 6
// last index
console.log(firstname.length-1); // print 5

//trim() :- use to remove spaces.
let str = "   Aniket   ";
console.log(str.length) // 12
str = str.trim(); //its return new string without spaces. i.e Aniket
console.log(str.length) // 6

//toLowerCase()
let str2 = "Aniket";
console.log(str2.toLowerCase());

//toUpperCase()
let str3 = "Aniket";
console.log(str3.toUpperCase());

//slice()
let str4 = "Aniket";
let str5 = str4.slice(0,4); //slice(start,end), slice(start);
console.log(str5) // Ani; // its take 0 to 3

// typeof operators

//data types
let str6 = "Aniket"; //type us string
let number = 12321; //type is no 
let bool = true;  // type is boolean
let a; // type is undefined;
let b = null // type is null;


//typeof() used to check type Variable its return variable type 

//trick to change string into no;
let mystr = +"34";
console.log(typeof(mystr)); //its number
mystr = Number(mystr);
console.log(typeof(mystr));

//trick to change num into str;
let myNum = 34 + "";
console.log(typeof(myNum)); //its str
myNum = String(myNum);
console.log(typeof(myNum));

// string concatination
let firstName = "Aniket";
var surname = "ugare";
console.log(firstName + surname); 
//there is also buildin function str.concat()

//template string
let string1 = "Aniket"
console.log(string1 + " " + "ugare")  //output = Aniket ugare
let aboutMe = `My name is ${string1}`;
console.log(aboutMe) // using template string

//undefined -> by default value of varibale is undefined for constant u need always assign somthing
// for let and var before assing value is undefined.

// null means nothing
let myvariable = null;
console.log(typeof myvariable); // typeof null always object its bug, error in js lot of code or framework is written 
//to typeof null is obj thats why they dont change it. 

//BigInt 
let bigNum = BigInt(1231232142345353) // or 123n is also BigInt
console.log(bigNum);
console.log(number.MAX_SAFE_INTEGER) // its will show max num 

//comparison operator
let num1 = 7;
let num2 = 7;
// < , >, <=, >=, ==, != these are the comparision operator
console.log(num1 >= num2) // its true.

//difference between == and ===
//== check with value same or not 
//=== check with value as well as datatype same or not.

// truthy and falsy values
// falsy values
// false
// 0
// null
// undefined
// ""

//truthy value 
//1
//"abc"
//true
//-1

//conditional operators
let age = 18;
if(age >= 18){
    console.log("Eligible for vote");
}else{
    console.log("not Eligible for vote");
}

//there is if else if else lader.

// ternary operator
// let mark = 60;
// let result;
// if(mark >= 35){
//   result = "pass";
// }else{
//   result = "fail"
// }

// we can did this with single expression
let mark = 60;
let result = mark >= 35 ? "pass" : "fail";
console.log(result)


// and or operator ,not

let fname = "Aniket";
let uage = 24;

if(fname[0] == "A" && uage >=18){
    console.log("both true")
}else if(fname[0] == "A" || uage <= 18){
    console.log("one of both is true");
}

// not is used to do false value true and true value false

if(!(uage > 18)){
    console.log(uage)
}else{
    console.log(fname);
}


//nested if else 

let marks = number(prompt("Enter marks")); // or +prompt("Enter marks");

if(marks > 35){
    if(marks > 50){
        console.log("second class");
    }else if(marks > 60){
        console.log("first class");
    }
}else{
    console.log("fail");
}


//switch case 

let option = 1

switch(option){

    case 0 : console.log("option 0");
             break;
    case 1 : console.log("option 1");
             break;
    case 2 : console.log("option 2");
             break;
    default :console.log("not in options");
             break; // here break is optional
}

//while loop
let i = 1;
while(i <= 10){
    console.log(i);
    i++;
}

//for loop
for(let i=1; i<=10; i++){
    console.log(i)
}

//continue break
for(let i=1; i<=10; i++){
    if(i==4){
       continue;
    }
    if(i==8){
       break;
    } 
    console.log(i)
}

//do while
let j = 1;
do {
    console.log(j);
    j++;
    
} while(j<=10);




 







