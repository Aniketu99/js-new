//the way to add javaScript with html

//parse means read files

//1.add script in head tag :-
/* 

<head>
<script src="script.js"></script> 
</head>

*/

//browser start parsing html when its get js file browser load javascript file 
//its stop parsing of html and Execute js file if we use dom in js file then there is erorr 


//2. add script file before close tag of body

/* 

<body>
<script src="script.js"></script> 
</body>

*/

//browser start parsing html then its get js file browser load javascript file 
//Execute js file.its better then above  but here is some problem.
//problem is it first parse html and load js then execute js 

//3.add script with async property in head tag :-
/* 

<head>
<script src="script.js" async></script> 
</head>

*/

//browser start parsing html when its get js file if there is async attribute browser load javascript file 
//as well as its parsing of html file simultinously and when js file completely load then browser stop the 
//parsing of html and execute js file and parsing stuck at middle if we use dom in js then there is chances of error 


//4.add script with defer property in head tag :- best way less time
/* 

<head>
<script src="script.js" defer></script> 
</head>

*/

//browser start parsing html when its get js file if there is defer attribute browser load javascript file 
//as well as its parsing of html file simultinously and when js file completely load then browser continue the 
//parsing of html when html parsing done then js is alredy loaded then its  execute js file.


//DOM : Document Object Model :-
//when website is loaded in bowser it create tree like structure and this tree like structure is called dom
/*


                                html

            head                                         body
 title                meta                   header                section


*/

//every js file has window object in GEC 
//so there is document object which is refer to html where we can access html element.
console.log(window.document) // its will display dom with human readable.
console.dir(window.document) // it will display document object.

// select element using getElementById();

console.log(document.getElementById("main-heading")); //it will return object
console.dir(document.getElementById("main-heading")); //it will display document object.

// select element using getElementsByClassName();

console.log(document.getElementsByClassName("header")); //it will return html collection
console.dir(document.getElementsByClassName("header")[0]); //it will display 0th position object.

// select element using querySelector() and querySelectorAll();

console.log(document.querySelector("#main-heading")); //it will return object
console.log(document.querySelectorAll(".nav-item")); //it will return nodeList

const MainHeading = document.querySelector("#main-heading");

console.log(MainHeading.textContent); // it will give you all the text which is retrun if it is hidden or whatever

MainHeading.textContent = "changing text content";

console.log(MainHeading.innerText); // it will give you present text not consider present but hidden

const MainHeading2 = document.querySelector("div.headline h2");

MainHeading2.style.color = "red";

MainHeading2.style.backgroundColor = "red";  // not background-color = use camelcase

//get and set attribute

var link = document.querySelector("a");

console.log(link.getAttribute("href"));

var inputElement = document.querySelector(".form-todo input");

console.log(inputElement.getAttribute("type"));


// html collection :- its array like collection

const navlink = document.getElementsByClassName("nav-item");
console.log(navlink);

//simple for loop 
//for of loop
//forEach we cant able to use

for (let i = 0; i < navlink.length; i++) {
    navlink[i].closest("a").style.color = "red"
}

const navArray = Array.from(navlink);  //convert html collection into array using array.form then use forEach

for (let item of navArray) {
    console.log(item);
}


//nodelist :- nodelist is collection of node 

const navlink2 = document.querySelectorAll("a");
console.log(navlink2);

//simple for loop 
//for of loop
//forEach loop

for (let i = 0; i < navlink.length; i++) {
    navlink2[i].style.color = "red"
}

for (let item of navlink2) {
    console.log(item);
}

navlink2.forEach(item => {
    console.log(item);
});


//InnerHtml means all things inside selected element

const headline = document.querySelector(".headline");

headline.innerHTML = "<h1>Inner html changed </h1>";

headline.innerHTML += "<h1>another thing added</h1>"; //for "" inside "" \"\"

console.log(headline);



/*
                            Document  // rootnode it is js object

                              html

         head             newline space                       body    


         these are parent and child nodes;
  
*/

//rootnode
console.log(document.getRootNode());

console.log(document.getRootNode().childNodes); //here we get child node of parent with nodelist

var rootElement = document.getRootNode().childNodes[0];

console.log(rootElement.childNodes) //nodelist [head,text,body];

//child relation
const headElementNode = rootElement.childNodes[0];
const textNode = rootElement.childNodes[1];
const bodynode = rootElement.childNodes[2];

console.log(headElementNode);
console.log(textNode);
console.log(bodynode);

//parent relation
console.log(headElementNode.parentNode); //it will return parent node

//sibling relation
console.log(headElementNode.nextSibling); //it will return the sibling which has same parent 

/*
  all the space remove by browser by default 

  if we want that then

  in css there is property call you need to set in universal selector

  white-spaces = normal by deafult
  we have to set it pre 

*/

console.log(headElementNode.nextElementsibling); //it will ignore newlinespaces

const h1 = document.querySelector("h1");
const div = h1.parentNode;

div.style.color = "red";

const body = document.body
body.style.color = "blue";

const head = document.querySelector("head");
const title = document.querySelector("title");

console.log(title.childNodes);

var container = document.querySelector(".container");
console.log(container.childNodes) //there is node with newspace
console.log(container.children) //there is node without newspace its return html collection.


const sectionTodo = document.querySelector(".section-todo");

console.log(sectionTodo.classList); // it return DomTokenList with list of classes

sectionTodo.classList.add("bg-dark");

sectionTodo.classList.remove("bg-dark");

sectionTodo.classList.contains("bg-dark"); // its return true or false

sectionTodo.classList.toggle("bg-dark"); // add if not there if there then remove


// InnerHtml 

let todoList = document.querySelector(".todo-list");

todoList.innerHTML = todoList.innerHTML + `<li>
    < span class="text" > Do this do that</span >
        <div class="todo-buttons">
            <button class="todo-btn done">Done</button>
            <button class="todo-btn remove">Remove</button>
        </div>
        </li > `;


//not good way it rander every item of ul each time

/*
   document.createElement()
   append
   prepend
   remove
*/ 
const li = document.createElement("li");
// const textnode = document.createTextNode("item value");
li.textContent = "item value";

todoList.append(li) // append and appendchild are same appenchild not working in internet explor
todoList.prepend(li); // app add above

var todo = document.querySelector(".todo-list li");

todo.remove();      //both same todo.removeChild();

//before and after
 li.textContent ="after";
 todoList.after(li);

 li.textContent ="before";
 todoList.before(li);


 // elem.insertadjacentHTML(where,html)
 //beforebegin
 //afterbegin
 //beforeend;
 //afterend;

 todoList.insertAdjacentHTML("beforebegin","<li>sub menu </li>");


var li = document.createElement("li");
var li2 = li.cloneNode(true) //true means deep copy it takes all child 
todoList.append(li) 
todoList.prepend(li); 
//in ul you can do prepend or append 
//if you want li -0 and li-2 then use
todoList.append(li) 
todoList.prepend(li2); 


//some old methods to support poor IE
//appendchild 
//removechild
//replacechild 
//insertBefore


var li = document.createElement("li");
li.textContent ="Aniket";
todoList.appendChild(li);
var referelement = document.querySelector(".todo-list li");
referelement.insertBefore(li,referelement) // first para which want to insert and second is which element before;
todoList.replaceChild(li,referelement)//replace new li with referelement
todoList.removeChild(referelement);


// static list vs live list

// queryselectorAll gives us static list
// or getElementsByClassName or getElementsByTagName 

const AllLi = document.querySelectorAll(".todo-list li");
const ul = document.querySelector(".todo-list");
const allhtmlcollectionli = ul.getElementsByTagName("li");
const newLi = document.createElement("li");
li.textContent = "new li";
ul.append(newLi);
console.log(AllLi); //its static list
console.log(allhtmlcollectionli) // its live list


//how to get diamentions of element
//height width

var sectionTodo2 = document.querySelector(".section-todo");

let obj = sectionTodo2.getBoundingClientRect() //it return obj 

console.log(obj) // there is height width and othere thing
