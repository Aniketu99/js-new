// object oriented JavaScript / prototypal Inheritance

//methods :- function inside obejct, class

const person = {
    firstName : "Aniket",
    age :25,
    about : function() {
        console.log(`person name is ${this.firstName}, and age is ${this.age}`);
    }
}

person.about();

// this :- this is refer to current object

var person1 = {
    firstName : "Aniket",
    age :20,
    about :display
}

var person2 = {
    firstName : "nitin",
    age :18,
    about :display
}

function display() {
    console.log(`person name is ${this.firstName}, and age is ${this.age}`);
}

person1.about();
person2.about();


//console.log(this) // it will display window which is an global object
// this === window

function fun(){
   console.log(this) // window object
}

window.fun();

function fun(){
    "use strict"
    console.log(this) // if use strict in function or global then undefined
}

fun(); 
// or you can call like
fun.call(); // same function call


// call apply bind method
//call : call besicall use to call method of anothere object


var person1 = {
    firstName : "Aniket",
    age :20,
    about : function(str,No){
        console.log(this.firstName,this.age,str,No);
    }
}

var person2 = {
    firstName : "nitin",
    age :18,
}

// dont do this person1.about().call() 

person1.about.call(person2); // need to pass object

//us can pass additional parameters 
person1.about.call(person2,"Aniket",18);

//Apply :- Apply is similar to call only we can pass parameter in form of array
person1.about.call(person2,["Aniket",18]);

//bind :- bind return function whenever we need we can call.

var funs = person1.about.bind(person2,"Aniket",18);

funs();

// Arrow functions

const user1 = {
    fun : () =>{
        console.log(this)   //output is window
        // In arrow function this refer to surrounded one level above objects means its not user1 its  window
    }
}

user1.fun() // output is window object
user1.fun.call(user1) // output is window

//we can do

var user = {
    fun(){
        console.log(this);
    }
}

user.fun();

//__proto__ of [[prototype]] :- its write on ecamascript 6 documentation

function createUser(firstName,lastName,age){
    let user = {};
    user.firstName = firstName;
    user.lastName = lastName;
    user.age = age;
    user.display = function(){
        console.log(this.firstName,this.lastName,this.age)
    }

    return user;
}

var user_s1 = createUser("A","u",1); 
user_s1.display();
// In this way every object create new display function at time of object creation

//here we can refer function to every user
var userMethods = {
    display: function(){
       console.log(this.firstName,this.lastName,this.age)
    }
}

function createUser(firstName,lastName,age){
    let user = {};
    user.firstName = firstName;
    user.lastName = lastName;
    user.age = age;
    user.display = userMethods.display; 

    return user;
}

var user_s2 = createUser("A","u",1); 
user_s2.display();

// there is anothere way to access functions 

var userMethods = {
    display: function(){
       console.log(this.firstName,this.lastName,this.age)
    }
}

function createUser(firstName,lastName,age){
    let user = Object.create(userMethods) //with help of this we can use usermethods object method with this object
    user.firstName = firstName;           //with help of __proto__
    user.lastName = lastName;
    user.age = age;
    return user;
}
//object.create also assign empty object litral

var user_s2 = createUser("Aniket","ugare",25); 
user_s2.display();


function hello(){
  console.log("hello world");
}

//javascript functions we can access like object

console.log(hello.name) // ite will dis play function name 

// we can set our own funtion properties 

hero.customproperty = "Aniket";
console.log(hero.customproperty);

// prototype is property of function 

console.log(hello.prototype); 

//Array.protoype object.protoype there is no prototype only function have prototype

hello.prototype.abc = "abc";
hello.prototype.xyz = "xyz";

//__proto__  vs   prototype

// __proto__ is refrence whereas prototype is an object

//there is another way we can get function 

function createUser(firstName,lastName,age){
    let user = Object.create(createUser.prototype) //this is chain we can set here proto 
    user.firstName = firstName;          
    user.lastName = lastName;
    user.age = age;
    return user;
}

createUser.prototype.display = function(){
    console.log(this.firstName,this.lastName);
}

let user = createUser("ANiket","ugare");
user.display();


// new keyword 
//1.it will create new object
//2. it will return this object automatically not need to write there
//3.with new function we can call construction function.
//3. if you are writting function with new keyword then function name first word is cap.


//this is contructor function which is create oject and return it so we can also accsses its prototype
function createUser(firstName,lastName,age){
    user.firstName = firstName;          
    user.lastName = lastName;
    user.age = age;
}

createUser.prototype.display = function(){
    console.log(this.firstName,this.lastName);
}

let user = new createUser("ANiket","ugare"); // because of constructor we can access its prototype
user.display();

for(key in user){
    if(user.hasOwnProperty(key)){
        console.log(key)  //it will only display is own property not prototype peroperty
    }
}

// we create array like this
var arr = [10,20,30,40,50];
//but internally its create
var number = new Array(1,2,3,4,5);
//here we can access Array construction function properties because of new 
//i.e flter, map , reduce, sort ,fill, slice, splice
console.log(number);


//classes in js

class MyName{

   constructor(firstName,lastName){

         this.firstName = firstName;
         this.lastName = lastName;
   }

   // automaticall set in prototype this methods.

   display(){
      console.log(this.firstName,this.lastName);
   }

}

let myname = new MyName("Aniket",'ugare');
myname.display();

console.log(Object.getPrototypeOf(myname));

//Inharitance :- derived one class properties into another class

class Animal{

    constructor(name,age){
       this.name = name;
       this.age = age;
    }

    eat(){
       console.log(this.name + "eating");
    }

    run(){
        console.log(this.name + "runing");
    }

}


//dog class
class Dog extends Animal{

  
 
}

const tommy = new Dog("tommy",3);
tommy.eat();
tommy.run();

//super keyword is use to access parent methods and properties;

class Animal {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }

    eat() {
        console.log(this.name + " eating");
    }

    run() {
        console.log(this.name + " running");
    }
}

// Dog class
class Dog extends Animal {
    constructor(name, age, speed) {
        super(name, age);
        this.speed = speed;
    }

    run() {
        console.log(`${this.name} is running at ${this.speed} kmph`);
    }

    eat() {
        super.eat(); 
        console.log(`at ${this.speed} kmph`);
    }
}

var tom = new Dog("Tom", 3, 4);
tom.run();
tom.eat();


// method overloading :- parent has same method which is decalre in child child object first prefer child method

//getter and setters

class MyName{

    constructor(firstName,lastName){
 
          this.firstName = firstName;
          this.lastName = lastName;
    }
 
    // automatically set in prototype this methods.
 
    display(){
       console.log(this.firstName,this.lastName);
    }

    get data(){
       console.log(this.firstName,this.lastName);
    }

    setName(first,last){  
        this.firstName = first;
        this.lastName = last;
    }

    set changeName(name){
        this.firstName = name;
    }
 
 }
 
 let mname = new MyName("Aniket",'ugare');
 mname.display(); //here you need to call
console.log(mname.data) // here you can directly with property with help of getter
mname.setName("ram",'u'); //it will set 
mname.display();  // it will display

//with help of set method
mname.changeName = "ANiket uagre";
mname.display();

//static methods : static methods cant need the object and we cant call with object

class Fun{
     
    static data = "abc";  //static property
     
    constructor(name){
       this.name = name;
    }

    static fun(){   //static function
        console.log("static method");
    }
  
}

Fun.fun();
console.log(Fun.data);


 