// object oriented JavaScript / prototypal Inheritance

//methods :- function inside obejct, class

const person = {
    firstName : "Aniket",
    age :25,
    about : function() {
        console.log(`person name is ${this.firstName}, and age is ${this.age}`);
    }
}

person.about();

// this :- this is refer to current object

var person1 = {
    firstName : "Aniket",
    age :20,
    about :display
}

var person2 = {
    firstName : "nitin",
    age :18,
    about :display
}

function display() {
    console.log(`person name is ${this.firstName}, and age is ${this.age}`);
}

person1.about();
person2.about();


//console.log(this) // it will display window which is an global object
// this === window

function fun(){
   console.log(this) // window object
}

window.fun();

function fun(){
    "use strict"
    console.log(this) // if use strict in function or global then undefined
}

fun(); 
// or you can call like
fun.call(); // same function call


// call apply bind method
//call : call besicall use to call method of anothere object


var person1 = {
    firstName : "Aniket",
    age :20,
    about : function(str,No){
        console.log(this.firstName,this.age,str,No);
    }
}

var person2 = {
    firstName : "nitin",
    age :18,
}

// dont do this person1.about().call() 

person1.about.call(person2); // need to pass object

//us can pass additional parameters 
person1.about.call(person2,"Aniket",18);

//Apply :- Apply is similar to call only we can pass parameter in form of array
person1.about.call(person2,["Aniket",18]);

//bind :- bind return function whenever we need we can call.

var funs = person1.about.bind(person2,"Aniket",18);

funs();

// Arrow functions

const user1 = {
    fun : () =>{
        console.log(this)   //output is window
        // In arrow function this refer to surrounded one level above objects means its not user1 its  window
    }
}

user1.fun() // output is window object
user1.fun.call(user1) // output is window

//we can do

var user = {
    fun(){
        console.log(this);
    }
}

user.fun();

//__proto__ of [[prototype]] :- its write on ecamascript 6 documentation

function createUser(firstName,lastName,age){
    let user = {};
    user.firstName = firstName;
    user.lastName = lastName;
    user.age = age;
    user.display = function(){
        console.log(this.firstName,this.lastName,this.age)
    }

    return user;
}

var user_s1 = createUser("A","u",1); 
user_s1.display();
// In this way every object create new display function at time of object creation

//here we can refer function to every user
var userMethods = {
    display: function(){
       console.log(this.firstName,this.lastName,this.age)
    }
}

function createUser(firstName,lastName,age){
    let user = {};
    user.firstName = firstName;
    user.lastName = lastName;
    user.age = age;
    user.display = userMethods.display; 

    return user;
}

var user_s2 = createUser("A","u",1); 
user_s2.display();

// there is anothere way to access functions 

var userMethods = {
    display: function(){
       console.log(this.firstName,this.lastName,this.age)
    }
}

function createUser(firstName,lastName,age){
    let user = Object.create(userMethods) //with help of this we can use usermethods object method with this object
    user.firstName = firstName;           //with help of __proto__
    user.lastName = lastName;
    user.age = age;
    return user;
}
//object.create also assign empty object litral

var user_s2 = createUser("Aniket","ugare",25); 
user_s2.display();


function hello(){
  console.log("hello world");
}

//javascript functions we can access like object

console.log(hello.name) // ite will dis play function name 

// we can set our own funtion properties 

hero.customproperty = "Aniket";
console.log(hero.customproperty);

// prototype is property of function 

console.log(hello.prototype); 

//Array.protoype object.protoype there is no prototype only function have prototype

hello.prototype.abc = "abc";
hello.prototype.xyz = "xyz";

//__proto__  vs   prototype

// __proto__ is refrence whereas prototype is an object





