// functions in javaScript
// function is block of code that perform perticular task 

// this is function declaration or defination
function oddEven(num){  // here num is parameter which is formal parameter
    return num % 2 == 0;
 }
 
 // this is function call or invoke
 let result = oddEven(4); // 4 is an argument which is acual parameter
 if(result){
     console.log("even");
 }else{
     console.log("odd");
 }

 // function expression
 //function acts as expression like function store in varible.
 const hello = function(){
    console.log("hello");
 }
 hello();

 //Arrow functions ->
 
 let str = "Aniket";
 
 const firstChar = (str)=>{   // you can write this like if there is one parameter
                             // str =>{} otherwise(item1,item2)+>{}
    return str[0];
 }

 console.log(firstChar());

 // also there is another way

 var isEven = num => num % 2 == 0;  // if function return in one line then you can write this way 
 console.log(isEven(2))             //id there is multiple line then use above


// hoisting in javaScript
// hoisting means we can use variable and function before declaration

hello();

function hello(){
   console.log("hello world");
}

console.log(hello); // undefined we can use before declare this is  hoisting 
var hello = "hello world";
console.log(hello); // hello world

// we cant able to do hoisting with let,const,function expression,Arrow function

// the function without name is called anonymous function  //imp


//function inside function

function fun(){
    
    const activity = function(){
        console.log("inside activity function")
    }

    const music = song => console.log("inside song function");

    console.log("inside fun function");

    activity();
    music("");

}

fun();


// lexical scope or lexical environment ->
// lexical scope or lexical environment means local memeory + lexical Scope or lexical environment of parent 

function outer(){

    let a = 10;

    const inner = ()=>{

        console.log(a);  // here in local memory a is not present in inner function
                         // so its taken from lexical enivronment of its parent like from outer function 
    }
    
}

// block scope VS function scope ->

//let and const are block scope. 
//var is function scope or global scope.


{
    let a = 10;
    const b = 3.14;
    var c = 20;
    console.log(a) // the output is 10
    console.log(b) // the output is 3.14
    console.log(c) // the output is 20
}

console.log(a) // not decalred error..
console.log(b) // not decalred error..
console.log(c) // the output is 20

//because a and b means let and const has block scope thats why we cant access it ouside block scope 
//where as var has function or global scope so we can access its anywhere in this file.


{
    var a = 10;
    console.log(a); // output 10
}

{
    var a = 20;
    console.log(a); // output 20 here a is present in local memory if not present here then its takes 
                    // from parent lexical envirnoment.
}

console.log(a); // output is 20;


// @deafult parameter ->

function add(a,b){
   console.log(a+b); // if there is 1 parameter not there then suppose b is not there then a + undefined = NaN
   //output is NaN   // undefind + undefined = NaN;
}

add(5);

// to avoid this before we do this 


function add(a,b){
   
    if(typeof b == "undefined"){
        b=0
    }

    console.log(a+b); 
 }
 
 add(5);

 //but now there is default parameter 

 function add(a,b=0){
    console.log(a+b);
 }
 
 add(5); //output is 5
 add(5,8) //output is 13


 // @rest parameters ->

 function fun2(val1 , val2, ...rest){
       console.log(val1);
       console.log(val2);
       console.log(rest);
 }
 
 fun2(1,2,3,4,5,6,7,8,9);

 // @parameter destructuring 

    //this is used with Object // in react we use
     
    const person = {
        firstName :"Aniket",
        lastName :"u"       
    }

    fun3(person);

    // function fun3(obj){
    //     console.log(obj.firstName);
    //     console.log(obj.lastName);
    // }

    function fun3({firstName,lastName}){
        console.log(firstName);
        console.log(lastName);
    }
     

// @Callback function ->
//A function we can pass as a parameter to anothere function is called call back function 

function myfun2(name){
    console.log("call back function");
    console.log(name);
}

function fun(myfun2){
    let name = "callback" 
    myfun2(name);
    console.log("fun function");
}

fun(myfun2);

// function returning function ->
function myfun(){
    return function(){
        return "hello world";
    }
}

let fun = myfun()
let ans = fun();
console.log(ans);

// high order function ->
// function we can pass as a parameter to another function or one function return another function is called
// high order function.
//i.e 1.Callback function 2.function returning function


























