// promise and network
// promise, async, await, fetch, XHR 

//promise :- promise represent to future value

//create the promise

const arr = [10,20,30,40,50,60,70,80,90];

var promise = new Promise((resolve,reject)=>{  
    if(arr.includes(20)){
        resolve("20 is present");
    }else{
        reject("20 is not present");
    }
});


//consume promise

promise.then((resolveValue)=>{
    console.log(resolveValue);
},(rejectValue)=>{
    console.log(rejectValue);
})


//reject condition and resolve not present 

const arr2 = [10,30,40,50,60,70,80,90];

var promise = new Promise((resolve,reject)=>{  
    if(arr2.includes(20)){
        resolve("20 is present");
    }else{
        reject("20 is not present");
    }
});


//consume promise

promise.then((resolveValue)=>{
    console.log(resolveValue);
},(rejectValue)=>{
    console.log(rejectValue);
});

//Another way 

promise.then( null ,(rejectValue)=>{
    console.log(rejectValue);
});

//Anohter way

promise.then((resolveValue)=>{
    console.log(resolveValue);
}).catch((error)=>{
    console.log(error);
});


//function return promise

function myPromise(){

    const arr = [10,20,30,40,50,60,70,80,90];

    return  new Promise((resolve,reject)=>{  
    if(arr.includes(20)){
        resolve("20 is present");
    }else{
        reject("20 is not present");
    }
   });
}

myPromise().then((resolveValue)=>{
    console.log(resolveValue);
},(rejectValue)=>{
    console.log(rejectValue);
});


//promise with setTimeOut

function myPromise(){

    const arr = [10,20,30,40,50,60,70,80,90];

    return  new Promise((resolve,reject)=>{  
       setTimeout(()=>{
        if(arr.includes(20)){
            resolve("20 is present");
        }else{
            reject("20 is not present");
        }
       },2000)
   });
}

myPromise().then((resolveValue)=>{
    console.log(resolveValue);
},(rejectValue)=>{
    console.log(rejectValue);
});


//promise.resolve -> it will return new promise

Promise.resolve(5).then((data)=> console.log(data));


//promise chaining 

function myPromise() {
    const arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];
    return new Promise((resolve, reject) => {  
        if (arr.includes(20)) {
            resolve("20 is present");
        } else {
            reject("20 is not present");
        }
    });
}

myPromise()
    .then((resolveValue) => {
        console.log(resolveValue); 
        return resolveValue;
    })
    .then((data) => {
        console.log(data); 
        return Promise.resolve(data);
    })
    .then((data2) => {
        console.log(data2);
    });


//In callback hell there is problem the code is not readable and maintainable

function changetext(element,text){
    return new promise((resolve,reject)=>{
        element.textcontent = text;
        resolve();
    });
}

changetext(h1,"text").then(()=>{
   return changetext(h2,"text-2");
}).then(()=>{
    return changetext(h3,"text-3");
});

//simple sytaxt

changetext(h1,"text").then(()=> changetext(h2,"text-2"))
.then(()=> changetext(h3,"text-3"));


//Ajax
//Asychronous javascript and xml

const xhr  = new XMLHttpRequest();
console.log(xhr);

//api call 
const xhr2 = new XMLHttpRequest();

xhr2.open("GET","https://fakestoreapi.com/users");

// xhr2.onreadystatechange = ()=>{
//     if(xhr2.readyState == 4){
//         console.log(JSON.parse(xhr2.response));
//     }
// }

//onload gives us direct readystate 4 

xhr2.onload = ()=>{
    console.log(JSON.parse(xhr2.response));
}

xhr2.onerror = ()=>{
   reject(new Error("not working"));
}

xhr2.send();


//fetch

fetch("https://fakestoreapi.com/users")
  .then((res) => {
    if (!res.ok) {
      throw new Error('Network response was not ok');
    }
    return res.json();
  })
  .then((data) => {
    console.log(data);
  })
  .catch((error) => {
    console.error('There was a problem with the fetch operation:', error);
  });



// async and await

async function getData(){
   const res = await fetch("https://fakestoreapi.com/users");
   const user = await res.json();
   return user;
}

//async function always return promise

getData().then((user)=>{
     console.log(user);
})