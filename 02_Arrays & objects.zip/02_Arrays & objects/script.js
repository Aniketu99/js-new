// intro to arrays
// reference type
// how to create array

//arrays -> collection of data.

let fruits = ["apple", "grapes", "mango", 1, true];
console.log(fruits); // all array
console.log(fruits[0]); // apple

var fruit = ["apple", "grapes", "mango"];
console.log(fruit);
fruit[1] = "banana"; //change first index
console.log(fruit);
let obj = {} // object literal
console.log(Array.isArray(fruit)); //true
console.log(Array.isArray(obj)); //false

//Arrays methods

fruit.push("banana"); //add elements at last index
fruit.pop(); //reomve elements at last index it retrun item at last index also.
fruit.unshift("banana") //add elements at start index
fruit.shift(); //reomve elements at start index it retrun item at start index also.
fruit.sort();

// primitive vs refrence data types
// primitive store in stack
var num1 = 6;
var num2 = num1;
console.log(num1); //6
console.log(num2); //6
num1++;
console.log("after increment");
console.log(num1); // 7
console.log(num2); // 6

//refrence store in heap
var arr1 = [1, 2, 3];
var arr2 = arr1;
console.log(arr1); //1,2,3
console.log(arr2); //1,2,3
arr1.push(4);
console.log(arr1); //1,2,3,4
console.log(arr2); //1,2,3,4


//how to clone array
var arr1 = [1, 2, 3];
var arr2 = arr1.slice(0); //clone using slice. //very fast
var arr2 = [].concat(arr1) // clone using concat
var arr2 = [...arr1];  //...sprade operator  // lot people use this
var arr2 = [].concat(arr1, [5, 6]);
var arr2 = [...arr1, 5, 6];
var arr2 = [...arr1, ...arr3];

// use const for create array
const arr4 = [1, 2, 3, 4];
console.log(arr4) // 1,2,3,4
arr4.push(5)
console.log(arr4); // 1,2,3,4,5
arr4 = [];
console.log(arr4) // error we cant reassign constant we can do with method like push pop but not reassign

//for loop 
var fruit = ["apple", "grapes", "mango"];
var uppercase = [];

for (let i = 0; i < fruit.length - 1; i++) {
    uppercase.push(fruit[i].toUpperCase());
}

console.log(uppercase);

//itrate with while loop
const arr5 = [1, 2, 3, 4];
let i = 0;
while (i < arr5.length) {
    console.log(arr5[i]);
    i++;
}

//for of loop 
var arr = [1, 2, 3, 4, 5];
for (let num of arr) {
    console.log(num);
}

//for in loop 
var arr = [1, 2, 3, 4, 5];
for (let index in arr) {
    console.log(arr[index]);
}

//Array destructuring ES6 feature -> shortcut for below code
var arr = [1, 2]
var a = arr[0];
var b = arr[1];

//swapping two no
var a = 10;
var b = 20;
var [a, b] = [b, a];
console.log("after swap", a, b)

var arr = [10, 20, 30, 40, 50]
var [vara, varb, ...newArray] = arr;
console.log(vara, varb, newArray)

//object -> obj is real word entity obj store in key value pairs
//how to create obj
const person = {
    name: "Aniket", //key value pair
    age: 24,
    language: ["hindi", "marathi", "english"]
}
console.log(person);
//how to access obj values
//using . notation
console.log(person.name);
console.log(person.age);
console.log(person.language);

//how to add key value pair
person.gender = "male";
console.log(person);
console.log(person["name"]); //another way without . operator bracket notation

//difference between dot and bracket notation
const person = {
    name: "Aniket", //key value pair
    age: 24,
    "speaking language": ["hindi", "marathi", "english"]
}

console.log(person["speaking language"]) // there is space in key with dot notation we cant print this 
// we need bracket notation for this.

//another diff

const key = "email";

const person = {
    name: "Aniket", //key value pair
    age: 24,
    "speaking language": ["hindi", "marathi", "english"]
}

//person.key = "email"  //not possible
person[key] = "Admin@gmail.com"
console.log(person);

//how to iterate object
//for in  loop and object.keys

//for in loop
for (let key in person) {
    console.log(key);  //display all keys
}

for (let key in person) {
    console.log(person[key]); // display all key values
}

//object.keys
console.log(Object.keys(person)); // its return array of keys
for (let key of Object.keys(person)) {
    console.log(person[key]);
}

//task computed values

var key1 = "key1";
var key2 = "key2";
var value1 = "val1";
var value2 = "var2";

let obj1 = {
    [key1]: value1,
    [key2]: value2   //[key] is called computed propertry
}

// let obj1 = {}

// obj1[key1]=value1;
// obj1[key2]=value2;

console.log(obj1);

//sprade operator

var arr1 = [1, 2, 3, 4];
var arr2 = [5, 6, 7, 8];

var newarr = [...arr1, ...arr2];
console.log(newarr);

const strsprade = [..."12345"] // it will sprade string and output is [1,2,3,4,5] it only work on itrable 
// i.e array string 

console.log(strsprade);

//sprade operator in object

var obj4 = {
    key1: "val1",
    key2: "val2",
    key1: "val3" // it will override value of key1 property
}

var obj5 = {
    key1: "val1",
    key2: "val2",
}

var obj6 = {
    key1: "unique",
    key3: "val3",
}

const newobj = { ...obj5, ...obj6, newkey: "value" };
console.log(newobj);

/* here output is

 newobj ={
    key1:"unique", // key1 value override because obj6 has key1 which override obj5 key1 
    key2:"val2",
     key3:"val3",
     newkey:"value"
 }

*/

var newobj2 = { ..."abc" };
var newobj3 = { ...[1, 2] };
console.log(newobj2);
console.log(newobj3);
/*
    output is 

    1st :

    newobj2 = {
      0:a,
      1:b,
      3:c
    }

    2nd 

    newobj3 = {
      0:1,
      1:2
    }

*/

var newobj2 = { ..."abc" };
var newobj3 = [...[1, 2], 3, ...[5, 6, 7]];
console.log(newobj2);
console.log(newobj3);

/*

 Output:

{ '0': 'a', '1': 'b', '2': 'c' }
[ 1, 2, 3, 5, 6, 7 ]

*/


//object destructuring
const band = {
    bandname: "led zeppliun",
    song: "heaven",
    year: 1668
};

var bandname = band.bandname;
var song = band.song;

console.log(bandname, song);

//shortcut with object destructuring

var { BandName, Bandsong, ...resproperty } = band;  // bydefault property name is variable name
console.log(BandName, Bandsong);
console.log(resproperty);

var { BandName: var1, Bandsong: var2 } = band; // we can change variable name 
console.log(var1, var1);


// object inside array json array
// very useful in real world applications

var users = [
    { userId: 1, userName: "Aniket" },
    { userId: 2, userName: "nitin" },
    { userId: 3, userName: "rohan" },
    { userId: 4, userName: "datta" }
]

for (let user of users) {
    console.log(user.userId, user.userName);
}


// nested destructuring

const users = [
    { userId: 1, userName: "Aniket" },
    { userId: 2, userName: "nitin" },
    { userId: 3, userName: "rohan" },
    { userId: 4, userName: "datta" }
]

// const [user1, user2 , user3] = users;
// console.log(user1);
// console.log(user2);
// console.log(user3);

const [{ userId, userName }, , { userName: xyz}, ...rest] = users;
console.log(userId,userName);
console.log(xyz);
console.log(rest);

/*

Output:

1 Aniket
rohan
[ { userId: 4, userName: 'datta' } ]

*/


